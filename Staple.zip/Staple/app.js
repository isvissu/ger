/**
  {{{ * Module dependencies.
 */

var express = require('express');
var cookieParser = require('cookie-parser');
var compress = require('compression');
var session = require('express-session');
var bodyParser = require('body-parser');
var logger = require('morgan');
var errorHandler = require('errorhandler');
var csrf = require('lusca').csrf();
var methodOverride = require('method-override');

var _ = require('lodash');
var MongoStore = require('connect-mongo')({ session: session });
var flash = require('express-flash');
var path = require('path');
var mongoose = require('mongoose');
var passport = require('passport');
var expressValidator = require('express-validator');
var connectAssets = require('connect-assets');

/**
  }}}*
  {{{* Controllers (route handlers).
 */

var homeController = require('./controllers/home');
var userController = require('./controllers/user');
var contactController = require('./controllers/contact');
var mobileController = require('./controllers/mobile');
var stappleController = require('./controllers/stapple');
var postController = require('./controllers/post');
var commentController = require('./controllers/comment');
var apiController = require('./controllers/apistapple');
var passController = require('./controllers/pass');
var api = require('./controllers/api');
/**
 * }}}
 {{{* API keys and Passport configuration.
 */

var secrets = require('./config/secrets');
var passportConf = require('./config/passport');

/**
 * }}}
 {{{ * Create Express server.
 */

var app = express();

/**
 * }}}
 {{{ * Connect to MongoDB.
 */

mongoose.connect(secrets.db);
mongoose.connection.on('error', function() {
  console.error('MongoDB Connection Error. Make sure MongoDB is running.');
});

var hour = 3600000;
var day = hour * 24;
var week = day * 7;

/**
 * }}}
 {{{ * CSRF whitelist.
 */

var csrfExclude = ['/url1', '/url2','/get/stapple'];

/**
 * }}}
 {{{ * Express configuration.
 */

app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');
app.use(compress());
app.use(connectAssets({
  paths: ['public/css', 'public/js'],
  helperContext: app.locals
}));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());
app.use(expressValidator());
app.use(methodOverride());
app.use(cookieParser());
app.use(session({
  secret: secrets.sessionSecret,
  store: new MongoStore({
    url: secrets.db,
    auto_reconnect: true
  })
}));
app.use(passport.initialize());
app.use(passport.session());
app.use(flash());
app.use(function(req, res, next) {
  // CSRF protection.
  if (_.contains(csrfExclude, req.path)) return next();
  csrf(req, res, next);
});
app.use(function(req, res, next) {
  // Make user object available in templates.
  res.locals.user = req.user;
  res.locals.stapple = req.stapple;
  next();
});
app.use(function(req, res, next) {
  // Remember original destination before login.
  var path = req.path.split('/')[1];
  if (/auth|login|logout|signup|img|fonts|favicon/i.test(path)) {
    return next();
  }
  req.session.returnTo = req.path;
  next();
});
app.use(express.static(path.join(__dirname, 'public'), { maxAge: week }));

exports.mustAuthenticatedMw = function (req, res, next){
  req.isAuthenticated()
    ? next()
    : res.redirect('/');
};

/**
 * }}}
 {{{ * Main routes.
 */

app.get('/', homeController.index);
app.get('/login', userController.getLogin);
app.get('/logout', userController.logout);
app.get('/contact', contactController.getContact);
app.post('/contact', contactController.postContact);
app.get('/account', passportConf.isAuthenticated, userController.getAccount);
app.post('/account/profile', passportConf.isAuthenticated, userController.postUpdateProfile);
app.post('/account/delete', passportConf.isAuthenticated, userController.postDeleteAccount);
app.get('/account/unlink/:provider', passportConf.isAuthenticated, userController.getOauthUnlink);
app.get('/mob' , mobileController.getmLogin);
app.get('/get/stapple' , stappleController.getStapple);
app.post('/get/stapple',stappleController.postStapple);
app.get('/stapple/:id',postController.index);
app.get('/search',commentController.index);
app.get('/get/stapple/:id' , function(req,res){
   var t  = stappleController.query(req.param('id'));
res.send("this is the json object\n"+ req.param('id') +"\n"+  stappleController.query(req.param('id')) );
} );
app.post('/search',commentController.postComments);
app.get('/search/:query',commentController.query);
app.post('/search/:query',commentController.postComments);
app.get('/s/:id',apiController.index);
app.get('/q/:q',apiController.find);
app.get('/pass/:a/:b/',passController.index);
//app.post('/api/login',api.login);
//app.post('/api/register',api.register);
//app.get('/api/logout',api.logout);

//app.get('/po/:i/:t/:d',stappleController.get);
//app.post('/po/:i/:t/:d',stappleController.postnew);
/**
 * }}}
 {{{ * OAuth sign-in routes.
 */
//app.get('/auth/local',passport.authenticate('local'));
app.get('/auth/facebook', passport.authenticate('facebook', { scope: ['email', 'user_location'] }));
app.get('/auth/facebook/callback', passport.authenticate('facebook', { failureRedirect: '/login' }), function(req, res) {
  res.redirect(req.session.returnTo || '/');
});
app.get('/auth/google', passport.authenticate('google', { scope: 'profile email' }));
app.get('/auth/google/callback', passport.authenticate('google', { failureRedirect: '/login' }), function(req, res) {
  res.redirect(req.session.returnTo || '/');
});
app.get('/auth/twitter', passport.authenticate('twitter'));
app.get('/auth/twitter/callback', passport.authenticate('twitter', { failureRedirect: '/login' }), function(req, res) {
  res.redirect(req.session.returnTo || '/');
});


/**
 * }}}
 {{{ * 500 Error Handler.
 */

app.use(errorHandler());

/**
 * }}}
 {{{ * Start Express server.
 */

app.listen(app.get('port'), function() {
  console.log('Express server listening on port %d in %s mode', app.get('port'), app.get('env'));
});

module.exports = app;
//}}}
