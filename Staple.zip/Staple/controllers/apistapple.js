var _ = require('lodash');
var async = require('async');
var crypto = require('crypto');
var passport = require('passport');
var Stapple = require('../models/Stapple');
var secrets = require('../config/secrets');

exports.index =  function (req , res ){
   Stapple.findById( req.param('id') , function (err , stapple ){
   if (err) { console.log(err);}
   if (stapple) {
   console.log(stapple);
   res.render('apist' , { s : stapple,});
   }
   });
};

exports.find = function (req,res){
   Stapple.find({title : req.param('q')}, function (err,stapples){
   if (err) { console.log(err);}
   if (stapples) {
   res.render('apist' , { s : stapples,});
   }
   });
};
