var _ = require('lodash');
var async = require('async');
var crypto = require('crypto');
var nodemailer = require('nodemailer');
var passport = require('passport');
var Stapple = require('../models/Stapple');
var secrets = require('../config/secrets');
exports.index = function(req,res){
   if (req.user){
   Stapple.findById( req.param('id') , function (err,stapple) {
   if (stapple) {
   console.log(stapple);
   res.render('stapple',{title : stapple.title,
                         image : stapple.image,
                         dec   : stapple.dec,
                         usr   : stapple.usr,});
   }
   });
   } else {
   Stapple.findById( req.param('id') , function (err,stapple) {
   if (stapple) {
   console.log(stapple);
   res.render('stapple',{title : stapple.title,
                         image : stapple.image,
                         dec   : stapple.dec,
                         usr   : stapple.usr,});
   }
   });


   }
   //console.log('not found');
 //res.render('stapple',{title : 'stapple |get'});
};
