var _ = require('lodash');
var async = require('async');
var crypto = require('crypto');
var nodemailer = require('nodemailer');
var passport = require('passport');
var Stapple = require('../models/Stapple');
var secrets = require('../config/secrets');

exports.getStapple = function(req ,res) {
 res.render('getstapple',{
  title: 'get | stapple'
 });
}

exports.postStapple = function(req,res,next) {
   if(req.user){
   var newstapple = new Stapple(
      {
      title : req.body.title || '',
      image : req.body.image || '',
      dec   : req.body.dec   || '',
      usr   : req.user.id    || '',
   });
   console.log('this is something'+ newstapple._id);
   newstapple.save(function(err,newstapple){
   if(err) return next(err);
   res.redirect('/stapple/'+newstapple._id);
   req.flash('sucess',{
   msg: 'stapple is created' });
   });
   } else {
   var newstapple = new Stapple(
      {
      title : req.body.title || '',
      image : req.body.image || '',
      dec   : req.body.dec   || '',
      usr   : '404',
   });
   console.log('this is something'+ newstapple._id);
   newstapple.save(function(err,newstapple){
   if(err) return next(err);
   res.redirect('/stapple/'+newstapple._id);
   req.flash('sucess',{
   msg: 'stapple is created' });
   });

   }
};

exports.postnew = function(req,res,next) {
   var newstapple = new Stapple(
      {
      title : req.param('i') || '' ,
      image : req.param('t') || '' ,
      dec   : req.param('d') || '' ,
   }
   );
   console.log('this is something'+ newstapple._id);
   res.redirect('/stapple/'+newstapple._id);
   req.flash('sucess',{  msg: 'stapple is created' });
};

exports.query = function (req,res){
//var query = req.id;
Stapple.findById( req , function (err,stapple) {
//if (err) return next(new Error('Failed to load Stapple'));
if (stapple) {
   //console.log(stapple);
  return stapple;
}
});
};
