var _ = require('lodash');
var async = require('async');
var crypto = require('crypto');
var nodemailer = require('nodemailer');
var passport = require('passport');
var Stapple = require('../models/Stapple');
var secrets = require('../config/secrets');
exports.index = function(req,res){
   res.render('search',{title : 'search'});
};
exports.postComments = function (req,res,next){
   //console.log(Stapple.find({title : req.body.search}));
   res.redirect('search/'+req.body.search);
};
exports.query = function (req,res){
   console.log(req.param('query'));
   Stapple.find({title : req.param('query') } , function (err,stapples){
   if (stapples){
   console.log(stapples);
   res.render('stapples', {title : "things",
                         stapples : stapples,});
   }else {
   console.log('not found');
   }
   });
}
