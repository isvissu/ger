var mongoose = require('mongoose');
var crypto = require('crypto');
var userSchema = new mongoose.Schema({
 password: {
     type: String
           },
 username: {
     type: String,
   unique: true,
lowercase: true
           },
    email: {
     type: String,
   unique: true,
lowercase: true,
           },
   pass:{
   type: String
   },
    local: {
    email: String,
     pass: String,
    },
 facebook: String,
  twitter: String,
   google: String,
   tokens: Array,
  profile: {
     name: {
     type: String,
  default: ''
           },
   gender: {
     type: String,
  default: ''
           },
 location: {
     type: String,
  default: '' },
  website: {
     type: String,
  default: ''
           },
  picture: {
     type: String,
  default: '' }
  },
});
/**
 * Get URL to a user's gravatar.
 * Used in Navbar and Account Management page.
 */
userSchema.methods.validPassword = function(pass) {
return pass == this.pass
}

userSchema.methods.gravatar = function(size) {
  if (!size) size = 200;
  if (!this.email) {
    return 'https://gravatar.com/avatar/?s=' + size + '&d=retro';
  }
  var md5 = crypto.createHash('md5').update(this.email).digest('hex');
  return 'https://gravatar.com/avatar/' + md5 + '?s=' + size + '&d=retro';
};
userSchema.methods.validPassword = function(pass) {
return (pass == this.password)
}
module.exports = mongoose.model('User', userSchema);
