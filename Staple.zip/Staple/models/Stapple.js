var mongoose = require('mongoose');
var crypto = require('crypto');
var stappleSchema = new mongoose.Schema({
title : {type : String , default : '' },
image : {type : String , default : '' },
dec   : {type : String , default : '' },
usr   : {type : String , default : '' },
});

module.exports = mongoose.model('Stapple.js',stappleSchema);
stappleSchema.methods.img = function() {
return this.image
};
stappleSchema.methods.title = function() {
return this.title
}
stappleSchema.methods.dec = function() {
return this.dec
}
stappleSchema.methods.usr = function() {
return this.usr
}

